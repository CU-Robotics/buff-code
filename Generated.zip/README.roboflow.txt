
Synthetic-Base-v4 - v4 2022-06-17 11:17pm
==============================

This dataset was exported via roboflow.ai on June 18, 2022 at 5:18 AM GMT

It includes 129 images.
Armor-moduels-armor-plates are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down


